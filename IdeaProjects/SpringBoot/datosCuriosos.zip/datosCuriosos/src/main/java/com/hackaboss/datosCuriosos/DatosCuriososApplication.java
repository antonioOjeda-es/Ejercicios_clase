package com.hackaboss.datosCuriosos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatosCuriososApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatosCuriososApplication.class, args);
	}

}
