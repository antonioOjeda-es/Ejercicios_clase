package com.hackaboss.datosCuriosos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatosCuriososApplicationTests {

	@Test
	void contextLoads() {
	}

}
