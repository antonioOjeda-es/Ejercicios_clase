package com.hackaboss.refranes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RefranesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RefranesApplication.class, args);
	}

}
